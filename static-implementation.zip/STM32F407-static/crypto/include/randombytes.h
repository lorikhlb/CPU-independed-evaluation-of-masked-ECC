#ifndef RANDOMBYTES_H
#define RANDOMBYTES_H

#include <stdint.h>

void randombytes(unsigned char *x, unsigned long long xlen);
void randomhalfword(uint16_t *x);

#endif