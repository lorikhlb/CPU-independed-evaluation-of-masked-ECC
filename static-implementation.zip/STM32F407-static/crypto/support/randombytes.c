#include "../include/randombytes.h"

// #include <libopencm3/stm32/rng.h>
#include <stdint.h>
#include <stdlib.h>

uint32_t get_random(void);
extern uint32_t randomness;

#pragma GCC push_options
#pragma GCC optimize ("O0")
 uint32_t get_random(){
  return randomness;
  //return rand();
}
#pragma GCC pop_options

void randombytes(unsigned char *x, unsigned long long xlen) {
  union {
    unsigned char aschar[4];
    uint32_t asint;
  } random;

  while (xlen > 4) {
    random.asint = get_random();
    *x++ = random.aschar[0];
    *x++ = random.aschar[1];
    *x++ = random.aschar[2];
    *x++ = random.aschar[3];
    xlen -= 4;
  }
  if (xlen > 0) {
    for (random.asint = get_random(); xlen > 0; --xlen) {
      *x++ = random.aschar[xlen - 1];
    }
  }
}

void randomhalfword(uint16_t *x) {
  *x = get_random() & 0x0000ffff;
}