#ifndef __MAIN_H
#define __MAIN_H

#include "test.h"
#include "./crypto/include/crypto_scalarmult.h"
#include "./crypto/include/bigint.h"
#include "./crypto/include/fe25519.h"
#include "./crypto/include/randombytes.h"
#include "./crypto/include/sc25519.h"
#include "./crypto/include/sc25519.h"

// Band-aid fix-definitions due to bugs with implicit-function-declaration
typedef struct {
  fe25519* x;
  fe25519* y;
  fe25519* z;
} point25519;

static const fe25519 CON486662 = {
    {0x06, 0x6d, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}};

static void curve25519_doublePoint(point25519* R, const point25519* P) {
  // x3 = 2y1z1^2 * (3x1^2z1+2ax1z1^2+z1^3)^2 - 8ay1^3z1^6 - 16x1y1^3z1^5
  // y3 = 4y1^2z1^3 * (3x1+az1) * (3x1^2z1+2ax1z1^2=z1^3) -
  // (3x1^2z1+2ax1z1^2=z1^3)^3 - 8y1^4z1^5
  fe25519 v1, v2, v3, v4, v5, v6, v7;

  fe25519_square(&v6, P->z);
  fe25519_mul(&v6, &v6, P->y);
  fe25519_add(&v6, &v6, &v6);
  fe25519_square(&v1, P->x);
  fe25519_mul(&v1, &v1, P->z);

  fe25519_add(&v2, &v1, &v1);
  fe25519_add(&v1, &v1, &v2);
  fe25519_square(&v2, P->z);
  fe25519_mul(&v2, &v2, P->x);
  fe25519_mul(&v2, &v2, &CON486662);

  fe25519_add(&v2, &v2, &v2);
  fe25519_add(&v1, &v1, &v2);
  fe25519_square(&v2, P->z);
  fe25519_mul(&v2, &v2, P->z);
  fe25519_add(&v1, &v1, &v2);

  fe25519_square(&v2, &v1);
  fe25519_mul(&v6, &v6, &v2);
  fe25519_square(&v3, P->z);
  fe25519_square(&v4, &v3);
  fe25519_mul(&v4, &v4, P->z);

  fe25519_square(&v3, P->y);
  fe25519_mul(&v4, &v4, &v3);
  fe25519_mul(&v4, &v4, P->y);
  fe25519_add(&v4, &v4, &v4);
  fe25519_add(&v4, &v4, &v4);

  fe25519_add(&v4, &v4, &v4);
  fe25519_mul(&v5, &v4, P->z);
  fe25519_mul(&v5, &v5, &CON486662);
  fe25519_sub(&v6, &v6, &v5);
  fe25519_mul(&v5, &v4, P->x);

  fe25519_square(&v7, P->z);
  fe25519_mul(&v7, &v7, P->z);
  fe25519_mul(&v3, &v3, &v7);
  fe25519_add(&v3, &v3, &v3);
  fe25519_add(&v3, &v3, &v3);

  fe25519_mul(&v7, &CON486662, P->z);
  fe25519_add(&v7, &v7, P->x);
  fe25519_add(&v7, &v7, P->x);
  fe25519_add(&v7, &v7, P->x);
  fe25519_mul(&v7, &v7, &v3);

  fe25519_add(&v5, &v5, &v5);
  fe25519_sub(R->x, &v6, &v5);

  fe25519_mul(&v7, &v7, &v1);
  fe25519_mul(&v2, &v2, &v1);
  fe25519_sub(&v7, &v7, &v2);
  fe25519_mul(&v5, &v4, P->y);
  fe25519_sub(R->y, &v7, &v5);

  fe25519_mul(R->z, &v4, P->z);
}

static void curve25519_addPoint(point25519* R, const point25519* P,
                                const point25519* Q) {
  // x3 = (y2z1 - y1z2)^2 * z1z2*(x2z1 - x1z2) - (x2z1-x1z2)^3*(a*z1z2 + x1z2 +
  // x2z1) y3 = ((2*x1z2 + x2z1) + a*z1z2) * (y2z1 - y1z2) * (x1z2 - x1z2)^2 -
  // z1z2*(y2z1 - y1z2)^3 - y1z2*(x2z1 - x1z2)^3 z3 = z1z2*(x2z1 - x1z2)^3

  // 16M + 3S + 10A
  fe25519 y2z1, y1z2, z1z2, x2z1, x1z2;
  fe25519 y2z1my1z2, x2z1mx1z2, x1z2px2z1;
  fe25519 AA, BB, CC, DD;

  fe25519_mul(&y2z1, Q->y, P->z);
  fe25519_mul(&y1z2, P->y, Q->z);
  fe25519_mul(&z1z2, P->z, Q->z);
  fe25519_mul(&x2z1, Q->x, P->z);
  fe25519_mul(&x1z2, P->x, Q->z);

  fe25519_sub(&y2z1my1z2, &y2z1, &y1z2);
  fe25519_sub(&x2z1mx1z2, &x2z1, &x1z2);
  fe25519_add(&x1z2px2z1, &x1z2, &x2z1);

  fe25519_square(&AA, &y2z1my1z2);
  fe25519_mul(&AA, &AA, &x2z1mx1z2);
  fe25519_mul(&AA, &AA, &z1z2);

  fe25519_mul(&BB, &CON486662, &z1z2);
  fe25519_add(&CC, &x1z2px2z1, &x1z2);
  fe25519_add(&CC, &CC, &BB);

  fe25519_square(&DD, &x2z1mx1z2);
  fe25519_mul(&x2z1mx1z2, &DD, &x2z1mx1z2);
  fe25519_mul(&DD, &DD, &y2z1my1z2);
  fe25519_mul(&DD, &DD, &CC);

  fe25519_add(&BB, &BB, &x2z1);
  fe25519_add(&BB, &BB, &x1z2);
  fe25519_mul(&BB, &BB, &x2z1mx1z2);

  fe25519_sub(R->x, &AA, &BB);

  fe25519_square(&AA, &y2z1my1z2);
  fe25519_mul(&AA, &AA, &y2z1my1z2);
  fe25519_mul(&AA, &AA, &z1z2);
  fe25519_sub(R->y, &DD, &AA);
  fe25519_mul(&AA, &y1z2, &x2z1mx1z2);
  fe25519_sub(R->y, R->y, &AA);

  fe25519_mul(R->z, &z1z2, &x2z1mx1z2);
}



#endif /* __MAIN_H */