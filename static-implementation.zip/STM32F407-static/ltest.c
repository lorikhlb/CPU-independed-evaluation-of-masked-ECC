int checkifxisapoint(fe25519* result, const fe25519* initialInput) {
    int maxAttempts = 1000;  // Set a limit to avoid infinite loops

    fe25519 input;
    fe25519_cpy (&input, initialInput);

    for (int attempt = 0; attempt < maxAttempts; attempt++) {
        int retval = computeY_curve25519_affine(result, &input);
        if (retval == 0) {
            // Successfully found the square root
            return 0;
        } else {
            // Modify the input and try again
            // Example: Increment the input by 1
            fe25519_generateRandomValue(&input, &input, &one);
            // You can apply any modification to 'input' here
        }
    }

    // If the loop reaches this point, it means no square root was found
    return -1;
}

// Calculate R and S.
void randomizepointblinding(fe25519* Rx, fe25519* Ry,fe25519*Rz,fe25519*Sx,fe25519*Sy,fe25519*Sz)
 {
  // creat strcuts and save the points R and S
  point25519 R, S;
  R.x = Rx;
  R.y = Ry;
  R.z = Rz;
  S.x = Sx;
  S.y = Sy;
  S.z = Sz;
  // creat structs to add onto R and S
  point25519 R0, S0;
  fe25519 rx0, ry0, rz0, sx0, sy0, sz0;
  R0.x = &rx0;
  R0.y = &ry0;
  R0.z = &rz0;
  S0.x = &sx0;
  S0.y = &sy0;
  S0.z = &sz0;
  fe25519_cpy(R0.x, R.x);
  fe25519_cpy(R0.y, R.y);
  fe25519_cpy(R0.z, R.z);
  fe25519_cpy(S0.x, S.x);
  fe25519_cpy(S0.y, S.y);
  fe25519_cpy(S0.z, S.z);

  uint16_t randbyte;
  randombytes(&randbyte, 1);
  int16_t nextBit = 13;
  while (nextBit >= 0) {
    curve25519_doublePoint(&R, &R);
    curve25519_doublePoint(&S, &S);
    if (randbyte & (1 << nextBit)) {
      curve25519_addPoint(&R, &R, &R0);
      curve25519_addPoint(&S, &S, &S0);
    }
    nextBit--;
  }
 //Set the new blinding Points to be used
  *Rx = R.x;
  *Ry = R.y;
  *Rz = R.z;
  *Sx = S.x;
  *Sy = S.y;
  *Sz = S.z;
}


  